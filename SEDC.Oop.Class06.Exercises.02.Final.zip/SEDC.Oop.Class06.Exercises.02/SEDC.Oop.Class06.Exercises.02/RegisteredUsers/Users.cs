﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEDC.Oop.Class06.Exercises._02.RegisteredUsers
{
    public class Users
    {

        public string Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        private static string[] MessagesArray { get; set; }



        public Users(string username, string password)
        {
            Username = username;
            Password = password;
            int idNumber = new Random().Next(1, 1000);
            Id = idNumber.ToString();
            MessagesArray[0] = "Prva poraka";
            MessagesArray[1]= "Vtora poraka";
        }

      
        public void LogIn(Users[] userExists, string username, string password)
        {
            Username = username;
            Password = password;

            foreach (Users user in userExists)
            {
                if (user.Username == Username && password == user.Password)
                {
                    Console.WriteLine($"Welcome {user.Username}, here are you messages:");

                    foreach (string message in MessagesArray)
                    {
                        Console.WriteLine(message);
                    }

                }

            }
                {
                    Console.WriteLine("There is no such user :( ");
                }
            


        }
        public void Register(Users[] userExists, string username, string password)
        {
            Users[] addedUsers = new Users[userExists.Length];
            bool flag = false;
            foreach (Users user in userExists)
            {
                if (user.Username == Username)
                {
                    Console.WriteLine("There is already a user with the same username! ");
                    flag = true;
                }

                else
                {
                    Users newUser = new Users(username, password);
                   addedUsers = AddNewUser(newUser, userExists);

                }

            }
            if (!flag)
            {
                    Console.WriteLine("Registration complete. All users:");
                foreach (Users cUser in addedUsers)
                {
                    Console.WriteLine($"{cUser.Id} {cUser.Username}");
                    Console.WriteLine();
                }
            }
        }

        private Users[] AddNewUser(Users user, Users[] usersExisting)
        {
            Array.Resize(ref usersExisting, usersExisting.Length + 1);
            usersExisting[usersExisting.Length-1] = user;
            return usersExisting;
        }





    }
}