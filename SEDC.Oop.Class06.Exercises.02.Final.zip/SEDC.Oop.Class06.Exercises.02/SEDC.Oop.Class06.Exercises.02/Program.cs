﻿using SEDC.Oop.Class06.Exercises._02.RegisteredUsers;
using System;

namespace SEDC.Oop.Class06.Exercises._02
{
    internal class Program
    {
        static void Main(string[] args)
        {
         
           Users[] userArray =
        {
           new Users ("Sofi", "jujkdshg"),
           new Users ("Chajche", "123"),
           new Users ("Alek", "hmhm")
        };
            bool flag = false;

            while (!flag)
            {
                Console.WriteLine("Welcome! Do you want to \n1.Log in or \n2.Register? Please, pick a number!");
                string choice = Console.ReadLine();

               
                if (choice != "1" && choice != "2")
                {
                    Console.WriteLine("Please, pick between number 1 and 2");
                    continue;
                }

                else
                {
                    if (choice == "1")
                    {
                        Console.WriteLine("Please, enter your username and password");
                        string username = Console.ReadLine();
                        string password = Console.ReadLine();
                        Users currentUser = new Users(username, password);
                        currentUser.LogIn(userArray, username, password);
                        flag = true;
                        break;
                    }

                    else if (choice == "2")
                    {
                        Console.WriteLine("Please, enter your username and password");
                        string username = Console.ReadLine();
                        string password = Console.ReadLine();
                        Users currentUser = new Users(username, password);
                        currentUser.Register(userArray, username, password);
                        flag=true;
                        break;
                    }
                }
            }


    }
    }
}
